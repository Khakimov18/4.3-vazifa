// if1
// let number = prompt("son");
// if (number > 0) {
//   number++;
// }
// console.log(number);

// if2;
// let number = prompt("son");
// if (number > 0) {
//   number++;
// } else {
//   number--;
// }
// console.log(number);

//if3
// let number = prompt("son");
// if (number > 0) {
//   number++;
// } else if (number == 0) {
//   console.log(10);
// } else {
//   number--;
// }
// console.log(number);

//if4
// let num1 = +prompt("son1");
// let num2 = +prompt("son2");
// let num3 = +prompt("son3");
// let count = 0;

// if (num1 > 0) {
//   count++;
// }
// if (num2 > 0) {
//   count++;
// }
// if (num3 > 0) {
//   count++;
// }
// console.log(count + " ta musbat son bor.");

//if5

// let num1 = +prompt("son1");
// let num2 = +prompt("son2");
// let num3 = +prompt("son3");
// let count = 0;
// let negative = 0;
// if (num1 > 0) {
//   count++;
// } else if (num1 < 0) {
//   negative++;
// }
// if (num2 > 0) {
//   count++;
// } else if (num2 < 0) {
//   negative++;
// }
// if (num3 > 0) {
//   count++;
// } else if (num3 < 0) {
//   negative++;
// }
// console.log(count + " ta musbat son bor va", negative + " ta manfiy son bor");

//if6
// let a = prompt("son1");
// let b = prompt("son2");
// if (a > b) {
//   console.log(a);
// } else {
//   console.log(b);
// }

//if7
// let a = prompt("son1");
// let b = prompt("son2");
// if (a < b) {
//   console.log(a);
// } else {
//   console.log(b);
// }

//if8
// let a = prompt("son1");
// let b = prompt("son2");
// if (a > b) {
//   console.log(a, b);
// } else {
//   console.log(b, a);
// }

//if9
// let a = prompt("son1");
// let b = prompt("son2");
// if (a > b) {
//   console.log(a, b);
// } else {
//   console.log(b, a);
// }

//if10
// let a = +prompt("son1");
// let b = +prompt("son2");
// if (a !== b) {
//   let sum = a + b;
//   a = b = sum;
// } else {
//   a = b = 0;
// }
// console.log("a =", a);
// console.log("b =", b);

//if11
// let a = prompt("son2");
// let b = prompt("son1");
// if (a != b && b != a) {
//   if (a > b) {
//     a = b;
//   } else {
//     b = a;
//   }
// } else {
//   a = b = 0;
// }
// console.log("a =", a);
// console.log("b =", b);

//if12
// let a = prompt("son1");
// let b = prompt("son2");
// let c = prompt("son3");
// if (a > b && b > c) {
//   console.log(c);
// } else if (a > b && c > b) {
//   console.log(b);
// } else if (b > a && c > a) {
//   console.log(a);
// }

//if13
// let a = prompt("son1");
// let b = prompt("son2");
// let a = prompt("son1");
// let b = prompt("son2");
// if (a < b) {
//   a++;
//   console.log(a++);
// } else if (a > b) {
//   b--;
//   console.log(b--);
// }

//if14
// let a = prompt("son1");
// let b = prompt("son2");
// let c = prompt("son3");
// if (a < b && a < c) {
//   console.log(a);
// } else if (b < a && b < c) {
//   console.log(b);
// } else if (c < a && c < b) {
//   console.log(c);
// }
// if (a > b && a > c) {
//   console.log(a);
// } else if (b > a && b > c) {
//   console.log(b);
// } else if (c > a && c > b) {
//   console.log(c);
// }

//boolean1
// let a = prompt("input");
// if (a > 0) {
//   console.log("A musbat son");
// }

//boolean2
// let a = prompt("input");
// if (a % 2 == 1) {
//   console.log("A toq son");
// }

//boolean3
// let a = prompt("input");
// if (a % 2 == 0) {
//   console.log("A juft son");
// }

//boolean4
// let a = prompt("intput1");
// let b = prompt("input2");
// if (a > 2 && b <= 3) {
//   console.log("true");
// } else {
//   console.log("false");
// }

//boolean5
// let a = prompt("intput1");
// let b = prompt("input2");
// if (a >= 0 && b <= -2) {
//   console.log("true");
// } else {
//   console.log("false");
// }

//boolean6
// let a = prompt("intput1");
// let b = prompt("input2");
// let c = prompt("input3");
// if (a <= b && b <= c) {
//   console.log("true");
// } else {
//   console.log("false");
// }

//boolean7
// let a = prompt("intput1");
// let b = prompt("input2");
// let c = prompt("input3");
// if (a > b && a < c) {
//   console.log("a soni b va c sonlari orasida yotadi");
// } else {
//   console.log("a soni b va c sonlari orasida yotmaydi");
// }

//boolean8
// let a = prompt("intput1");
// let b = prompt("input2");
// if (a % 2 == 1 && b % 2 == 1) {
//   console.log("a va b sonlari toq sonlar");
// } else {
//   console.log("a va b sonlari toq sonlar emas");
// }

//boolean9
// let a = prompt("intput1");
// let b = prompt("input2");
// if (a % 2 == 1 && b % 2 == 0) {
//   console.log(
//     "a va b sonlari toq sonlarining hech bo'lmaganda bittasi toq son"
//   );
// } else if (a % 2 == 0 && b % 2 == 1) {
//   console.log(
//     "a va b sonlari toq sonlarining hech bo'lmaganda bittasi toq son"
//   );
// } else {
//   console.log("toq son yo'q");
// }

//boolean10
// let a = prompt("intput1");
// let b = prompt("input2");
// if (a % 2 == 1 && b % 2 == 0) {
//   console.log("a va b sonlari toq sonlarining faqat bittasi toq son");
// } else if (a % 2 == 0 && b % 2 == 1) {
//   console.log("a va b sonlari toq sonlarining faqat bittasi toq son");
// } else {
//   console.log("toq son yo'q");
// }

//boolean11
// let a = prompt("intput1");
// let b = prompt("input2");
// if (a % 2 == 1 && b % 2 == 1) {
//   console.log("a va b sonlari toq sonlarining ikkalasi ham toq son");
// } else if (a % 2 == 0 && b % 2 == 0) {
//   console.log("a va b sonlari toq sonlarining ikkalasi ham juft  son");
// } else {
//   console.log("ikkalasi toq yoki juft emas");
// }

//boolean12
// let a = prompt("intput1");
// let b = prompt("input2");
// let c = prompt("input3");
// if (a > 0 && b > 0 && c > 0) {
//   console.log("a b c larning har biri musbat");
// } else {
//   console.log("a b c larning har biri musbat emas");
//}

//boolean13
// let a = prompt("intput1");
// let b = prompt("input2");
// let c = prompt("input3");
// if (
//   (a > 0 && b < 0 && c < 0) ||
//   (a < 0 && b > 0 && c < 0) ||
//   (a < 0 && b < 0 && c > 0)
// ) {
//   console.log("a, b, c larning hech bo'lmaganda bittasi musbat");
// } else {
//   console.log("musbat son yo'q");
// }

//boolean14
// let a = prompt("intput1");
// let b = prompt("input2");
// let c = prompt("input3");
// if (
//   (a > 0 && b < 0 && c < 0) ||
//   (a < 0 && b > 0 && c < 0) ||
//   (a < 0 && b < 0 && c > 0)
// ) {
//   console.log("a, b, c larning faqat bittasi musbat");
// } else if (a < 0 && b < 0 && c < 0) {
//   console.log("musbat son yo'q");
// } else {
//   console.log("musbat sonlar 2 ta yoki undan ko'p");
// }

//boolean15
// let a = prompt("intput1");
// let b = prompt("input2");
// let c = prompt("input3");
// if (
//   (a > 0 && b > 0 && c < 0) ||
//   (a > 0 && b < 0 && c > 0) ||
//   (a < 0 && b > 0 && c > 0)
// ) {
//   console.log("a, b, c larning faqat ikkittasi musbat");
// } else if (a < 0 && b < 0 && c < 0) {
//   console.log("musbat son yo'q");
// } else {
//   console.log("musbat sonlar 2 ta yoki undan ko'p");
// }

//noolean16
let num = prompt("input");
if (num >= 10 && num < 100 && num % 2 === 0) {
  console.log("ikki xonali juft son");
} else {
  console.log("ikki xonalik juft son emas");
}
